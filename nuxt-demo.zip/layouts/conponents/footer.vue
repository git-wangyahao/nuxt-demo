<template>
  <div class="footer">
    <p>作者：前端一课</p>
    <p>版权所有，侵权必究</p>
  </div>
</template>

<style lang="scss" scoped>
  .footer {
    color: #333;
    width: 100%;
    margin-bottom: 10px;
    p {
      text-align: center;
      font-size: 12px;
      padding: 2px;
    }
  }
</style>
