<template>
    <div class="logo">
      <nuxt-link to="/">Logo</nuxt-link>
    </div>
</template>

<style>
  .logo {
    width: 100px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    background-color: rosybrown;
  }
</style>
